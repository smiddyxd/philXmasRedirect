// New Tab script
document.addEventListener('DOMContentLoaded', (event) => {
    document.getElementById('background-video').play();
});